
import com.mysql.jdbc.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author SY
 */
public class Connecter {
     Connection con;
     public Connecter(){
         try {
             Class.forName("conn.mysql.jdbc.Driver");
         } catch (ClassNotFoundException e) {
             System.err.println(e); 
         }
         try {
             con = (Connection) DriverManager.getConnection( "jdbc:mysql://localhost:3306/jee_etudiant","root","");
         } catch (SQLException e) {
             System.err.println(e);
         }
     }
     Connection obtenirconnexion(){
         return con;
     }
}
